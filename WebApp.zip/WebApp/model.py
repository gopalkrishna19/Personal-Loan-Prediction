#Pandas display settings, decimals, scientfic notation removals, Increase cell width, charts, 
import pandas as pd
import pickle
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np
pd.options.display.float_format = '{:,.2f}'.format
from IPython.core.display import display, HTML
display(HTML("<style>.container {width : 98% !important; }</style>"))

import warnings
warnings.filterwarnings('ignore')

data = pd.read_excel('ML Case Study.xlsx','Data')
from scipy import stats
from sklearn import metrics

from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import NearestNeighbors
from sklearn import naive_bayes
from sklearn.ensemble import RandomForestClassifier

#Splitting Training and Test Set
#Since we have a very small dataset, we will train our model with all availabe data.

from sklearn.linear_model import LinearRegression
regressor = LogisticRegression()
x = data.drop('Personal Loan',axis = 1)
x = x.drop('ID',axis = 1)
x = x.drop('ZIP Code',axis = 1)
x = x.drop('Age',axis = 1)#Since we are including Experience
y = data['Personal Loan']
from sklearn.model_selection import train_test_split
XT,Xt,YT,Yt = train_test_split(x,y,test_size=0.30)
regressor.fit(XT,YT)

# Saving model to disk
pickle.dump(regressor, open('model.pkl','wb'))

# Loading model to compare the results
model = pickle.load(open('model.pkl','rb'))
print(model.predict([[1,2,3,4,5,6,7,8,9,10]]))