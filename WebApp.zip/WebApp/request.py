import requests

url = 'http://localhost:5000/predict_api'
r = requests.post(url,json={'Experience':1,'Income':49,'Family':4,'CCAvg':1.6,'Education':1,'Mortgage':0,'Securities Account':1,'CD Account':0,'Online':0,'CreditCard':0})
print(r.json())